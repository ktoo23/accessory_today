const productsData = [
    {productName:'A',category:'ring',price:10000},
    {productName:'B',category:'necklace',price:20000},
    {productName:'C',category:'earring',price:30000},
    {productName:'D',category:'bracelet',price:40000},
  ]
  
  export { productsData }