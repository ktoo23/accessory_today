import express from "express";
import { productRouter } from "./routers/productsRouter.js";
import { homeService } from "./services/productService.js";

const app = express();

app.use(express.json());

app.get('/api', async (req, res) => {
    const bestData= await homeService.getBest();
    const newData= await homeService.getNew();
    res.json([bestData,newData]);
});

app.use("/api/products",productRouter);

export {app};